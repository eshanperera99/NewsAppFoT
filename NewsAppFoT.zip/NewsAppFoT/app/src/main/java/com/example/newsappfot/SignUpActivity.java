package com.example.newsappfot;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {

    private EditText signupEmailEditText, signupFullNameEditText, signupPasswordEditText;
    private ImageView signupTogglePassword;
    private boolean isPasswordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up); // Make sure this is correct layout file name

        // Correct ID references from XML
        signupEmailEditText = findViewById(R.id.signupEmailEditText);
        signupFullNameEditText = findViewById(R.id.signupFullNameEditText);
        signupPasswordEditText = findViewById(R.id.signupPasswordEditText);
        signupTogglePassword = findViewById(R.id.signupTogglePassword);

        Button signUpButton = findViewById(R.id.signUpButton);
        Button loginButton = findViewById(R.id.loginButton);

        // Toggle Password Visibility
        signupTogglePassword.setOnClickListener(v -> {
            if (isPasswordVisible) {
                signupPasswordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                signupTogglePassword.setImageResource(R.drawable.ic_visibility_off);
            } else {
                signupPasswordEditText.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                signupTogglePassword.setImageResource(R.drawable.ic_visibility);
            }
            isPasswordVisible = !isPasswordVisible;
            signupPasswordEditText.setSelection(signupPasswordEditText.getText().length());
        });

        // Handle Sign Up Button
        signUpButton.setOnClickListener(v -> {
            String email = signupEmailEditText.getText().toString();
            String name = signupFullNameEditText.getText().toString();
            String password = signupPasswordEditText.getText().toString();

            if (email.isEmpty() || name.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Signed up: " + name, Toast.LENGTH_SHORT).show();
                // You can add saving to database or navigation here
            }
        });

        // Navigate back to Login Page
        loginButton.setOnClickListener(v -> {
            Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
